import hmfull

print(hmfull.HM.Nekos.sfw.foxgirl())