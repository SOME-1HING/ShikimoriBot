import fetchAPI
import hmtai

hmlinks = fetchAPI.HMrequest


class HM:
    class HMtai:
        class sfw:
            def wallpaper():
                return { "url": hmtai.wallpaper() }
            
            def mobileWallpaper():
                return { "url": hmtai.mobileWallpaper() }
            
            def neko():
                return { "url": hmtai.neko() }
            
            def jahy():
                return { "url": hmtai.jahy() }
            
            def slap():
                return { "url": hmtai.slap() }
            
            def lick():
                return { "url": hmtai.lick() }
            
            def depression():
                return { "url": hmtai.depression() }

        class nsfw:

            def ass():
                return { "url": hmtai.nsfw.ass() }
            
            def bdsm():
                return hmtai.nsfw.bdsm()
            
            def blowjob():
                return { "url": hmtai.nsfw.blowjob() }
            
            def boobjob():
                return { "url": hmtai.nsfw.boobjob() }
            
            def creampie():
                return { "url": hmtai.nsfw.creampie() }
            
            def cum():
                return { "url": hmtai.nsfw.cum() }
            
            def vagina():
                return { "url": hmtai.nsfw.vagina() }
            
            def uniform():
                return { "url": hmtai.nsfw.uniform() }
            
            def manga():
                return { "url": hmtai.nsfw.manga() }
            
            def foot():
                return { "url": hmtai.nsfw.foot() }
            
            def femdom():
                return { "url": hmtai.nsfw.femdom() }
            
            def gangbang():
                return { "url": hmtai.nsfw.gangbang() }
            
            def hentai():
                return { "url": hmtai.nsfw.hentai() }
            
            def incest():
                return { "url": hmtai.nsfw.incest() }
            
            def ahegao():
                return { "url": hmtai.nsfw.ahegao() }
            
            def neko():
                return { "url": hmtai.nsfw.nsfwNeko() }
            
            def gif():
                return { "url": hmtai.nsfw.gif() }
            
            def ero():
                return { "url": hmtai.nsfw.ero() }
            
            def cuckold():
                return { "url": hmtai.nsfw.cuckold() }
            
            def orgy():
                return { "url": hmtai.nsfw.orgy() }
            
            def elves():
                return { "url": hmtai.nsfw.elves() }
            
            def pantsu():
                return { "url": hmtai.nsfw.pantsu() }
            
            def nsfwMobileWallpaper():
                return { "url": hmtai.nsfw.nsfwMobileWallpaper() }
            
            def glasses():
                return { "url": hmtai.nsfw.glasses() }
            
            def tentacles():
                return { "url": hmtai.nsfw.tentacles() }
            
            def thighs():
                return { "url": hmtai.nsfw.thighs() }
            
            def yuri():
                return { "url": hmtai.nsfw.yuri() }
            
            def zettaiRyouiki():
                return { "url": hmtai.nsfw.zettaiRyouiki() }
            
            def masturbation():
                return { "url": hmtai.nsfw.masturbation() }
            
            def public():
                return { "url": hmtai.nsfw.public() }
    class Nekos:
        def balls():
            return hmlinks.nekosGet("8ball")
        class sfw:
            def slap():
                return hmlinks.nekosGet('slap')
            
            def pat():
                return hmlinks.nekosGet('pat')
            
            def neko():
                return hmlinks.nekosGet('neko')
            
            def kiss():
                return hmlinks.nekosGet('kiss')
            
            def hug():
                return hmlinks.nekosGet('hug')
            
            def feed():
                return hmlinks.nekosGet('feed')
            
            def cuddle():
                return hmlinks.nekosGet('cuddle')
            
            def smug():
                return hmlinks.nekosGet('smug')
            
            def tickle():
                return hmlinks.nekosGet('tickle')
            
            def foxgirl():
                return hmlinks.nekosGet('fox_girl')
            
            def waifu():
                return hmlinks.nekosGet('waifu')
        class nsfw:
            def nekogif():
                return hmlinks.nekosGet('ngif')
            def wallpaper():
                return hmlinks.nekosGet('wallpaper')
    class NekoLove:
        class sfw:
            def pat():
                return hmlinks.nekoloveGet('pat')
            
            def hug():
                return hmlinks.nekoloveGet('hug')
            
            def kiss():
                return hmlinks.nekoloveGet('kiss')
            
            def cry():
                return hmlinks.nekoloveGet('cry')
            
            def slap():
                return hmlinks.nekoloveGet('slap')
            
            def smug():
                return hmlinks.nekoloveGet('smug')
            
            def punch():
                return hmlinks.nekoloveGet('punch')
            
            def neko():
                return hmlinks.nekoloveGet('neko')
            
            def kitsune():
                return hmlinks.nekoloveGet('kitsune')
            
            def waifu():
                return hmlinks.nekoloveGet('waifu')
        class nsfw:
            def nekolewd():
                return hmlinks.nekoloveGet('nekolewd')
    class NekoBot:
        class sfw:
            def kanna():
                return hmlinks.nekobotGet('kanna')
            
            def neko():
                return hmlinks.nekobotGet('neko')
            
            def holo():
                return hmlinks.nekobotGet('holo')
            
            def kemonomimi():
                return hmlinks.nekobotGet('kemonomimi')
            
            def coffee():
                return hmlinks.nekobotGet('coffee')
            
            def gah():
                return hmlinks.nekobotGet('gah')
        class nsfw:
            def hentai():
                return hmlinks.nekobotGet('hentai')
            
            def hass():
                return hmlinks.nekobotGet('hass')
            
            def boobs():
                return hmlinks.nekobotGet('hboobs')
            
            def paizuri():
                return hmlinks.nekobotGet('paizuri')
            
            def yuri():
                return hmlinks.nekobotGet('hyuri')
            
            def thigh():
                return hmlinks.nekobotGet('hthigh')
            
            def lewdneko():
                return hmlinks.nekobotGet('lewdneko')
            
            def midriff():
                return hmlinks.nekobotGet('hmidriff')
            
            def kitsune():
                return hmlinks.nekobotGet('hkitsune')
            
            def tentacle():
                return hmlinks.nekobotGet('tentacle')
            
            def anal():
                return hmlinks.nekobotGet('hentai_anal')
            
            def hanal():
                return hmlinks.nekobotGet('hanal')
            
            def hneko():
                return hmlinks.nekobotGet('nheko')
            
